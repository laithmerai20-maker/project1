import { motion } from 'motion/react';
import { 
  CheckCircle, 
  Globe, 
  Rocket, 
  ArrowRight,
  Zap,
  Users,
  ShieldCheck,
  MousePointer2,
  Clock,
  DollarSign,
  AlertCircle
} from 'lucide-react';

const PlanCard = ({ title, desc, price, popular }: { title: string; desc: string; price: string; popular?: boolean }) => (
  <div className={`p-8 rounded-[24px] border transition-all ${popular ? 'border-bh-accent bg-white shadow-xl scale-105 z-10' : 'border-black/5 bg-white/50'}`}>
    {popular && (
      <div className="bg-bh-accent text-white text-[10px] font-black uppercase tracking-widest py-1 px-3 rounded-full inline-block mb-4">
        Most Popular
      </div>
    )}
    <h3 className="text-xl font-bold mb-2">{title}</h3>
    <p className="text-bh-ink-light text-sm mb-6 h-10">{desc}</p>
    <div className="flex items-baseline gap-1 mb-8">
      <span className="text-3xl font-black">${price}</span>
      <span className="text-bh-ink-light text-sm">/mo*</span>
    </div>
    <button className={`w-full py-4 rounded-xl font-bold transition-transform active:scale-95 ${popular ? 'bg-bh-blue text-white' : 'bg-bh-accent/10 text-bh-blue hover:bg-bh-accent/20'}`}>
      Select Plan
    </button>
  </div>
);

const BenefitItem = ({ icon: Icon, title, desc }: { icon: any, title: string, desc: string }) => (
  <div className="flex gap-4 p-6 bg-white rounded-2xl border border-black/5">
    <div className="flex-shrink-0 w-12 h-12 rounded-full bg-bh-accent/10 flex items-center justify-center text-bh-blue">
      <Icon className="w-6 h-6" />
    </div>
    <div>
      <h4 className="font-bold mb-1">{title}</h4>
      <p className="text-sm text-bh-ink-light leading-relaxed">{desc}</p>
    </div>
  </div>
);

export default function App() {
  return (
    <div className="min-h-screen bg-bh-bg text-bh-ink font-sans selection:bg-bh-accent/20">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-black/5 py-4 px-6 md:px-12 flex items-center justify-between">
        <div className="flex items-center gap-2 font-black text-xl tracking-tighter text-bh-blue">
          <Globe className="w-6 h-6 stroke-[3px]" />
          bluehost
        </div>
        <button className="bg-bh-accent text-white px-6 py-2.5 rounded-full font-bold text-sm shadow-lg shadow-bh-accent/20 hover:scale-105 transition-transform">
          Start Now
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative px-6 pt-20 pb-32 md:pt-32 md:pb-48 flex flex-col items-center text-center">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-bh-accent/5 rounded-full blur-[120px]" />
          <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-bh-blue/5 rounded-full blur-[100px]" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10 max-w-4xl"
        >
          <div className="inline-flex items-center gap-2 bg-bh-blue/5 text-bh-blue px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest mb-8 border border-bh-blue/10">
            <Zap className="w-3 h-3 fill-bh-blue" /> No Tech Skills Required
          </div>
          <h1 className="text-5xl md:text-8xl font-black tracking-tighter text-bh-blue mb-8 leading-[0.9]">
            Building a website <br className="hidden md:block" />
            <span className="text-bh-accent underline decoration-8 decoration-bh-accent/20 underline-offset-8 italic">doesn't</span> have to be hard.
          </h1>
          <p className="text-xl md:text-2xl text-bh-ink-light max-w-2xl mx-auto mb-12 font-medium">
            Launch your site in minutes, even with zero technical experience. We handle the hard part.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="w-full sm:w-auto bg-bh-blue text-white px-10 py-5 rounded-[20px] font-black text-xl shadow-2xl flex items-center justify-center gap-3 group transition-transform hover:scale-105">
              Start Your Website Now
              <ArrowRight className="w-6 h-6 transition-transform group-hover:translate-x-2" />
            </button>
            <p className="text-sm font-bold text-bh-ink-light italic">Over 2 Million Sites Hosted</p>
          </div>
        </motion.div>

        {/* Hero Visual Laptop */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-20 w-fit relative"
        >
          <div className="bg-bh-blue p-2 rounded-t-[20px] border-x-8 border-t-8 border-bh-blue shadow-2xl">
            <img 
              src="https://picsum.photos/seed/clean-dashboard/1000/600" 
              alt="Laptop View"
              referrerPolicy="no-referrer"
              className="w-[300px] md:w-[600px] rounded-t-lg grayscale opacity-90"
            />
          </div>
          <div className="h-4 bg-bh-blue/90 w-[340px] md:w-[680px] -mx-5 rounded-b-xl shadow-2xl border-t border-white/10" />
          
          <div className="absolute -right-8 bottom-12 bg-white px-6 py-4 rounded-2xl shadow-xl border border-black/5 flex items-center gap-4 animate-bounce">
             <CheckCircle className="w-10 h-10 text-bh-success" />
             <div className="text-left leading-tight">
               <div className="font-black text-lg">LIVE!</div>
               <div className="text-[10px] uppercase font-bold text-bh-ink-light tracking-widest">Setup Complete</div>
             </div>
          </div>
        </motion.div>
      </section>

      {/* Problem Section */}
      <section className="bg-white py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-5xl font-black tracking-tight text-center mb-16 text-bh-blue">
            Feeling stuck before <br className="hidden md:block" /> you even start?
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <p className="text-lg text-bh-ink font-medium">Most beginners hit the same walls:</p>
              {[
                "“I’m not a tech person, code scares me.”",
                "“Everything seems too expensive and complicated.”",
                "“I don't know where to host my files.”"
              ].map((text, i) => (
                <div key={i} className="flex items-center gap-4 text-bh-ink-light">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <span className="italic">{text}</span>
                </div>
              ))}
              <p className="pt-4 text-bh-ink leading-relaxed">
                We get it. It feels overwhelming. But what if you could skip the frustration and go straight to the <span className="font-bold underline">results</span>?
              </p>
            </div>
            <div className="bg-bh-bg rounded-[32px] p-8 flex items-center justify-center border border-black/5">
              <div className="text-center">
                <Users className="w-16 h-16 text-bh-blue mb-6 mx-auto opacity-20" />
                <h3 className="text-xl font-black mb-2 leading-tight">Join millions of beginners who made the switch.</h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-24 px-6 md:px-12 bg-bh-bg">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
             <div>
               <h2 className="text-3xl md:text-5xl font-black tracking-tight text-bh-blue">Your All-in-One Launchpad</h2>
               <p className="text-bh-ink-light text-lg mt-2 font-medium">Everything linked, automatically configured.</p>
             </div>
             <button className="text-bh-blue font-bold flex items-center gap-1 hover:underline">
               Explore all features <ArrowRight className="w-4 h-4" />
             </button>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <BenefitItem icon={Globe} title="Free Domain" desc="Your unique address, included for the first year." />
            <BenefitItem icon={ShieldCheck} title="SSL Security" desc="Built-in protection for you and your visitors." />
            <BenefitItem icon={Zap} title="1-Click Install" desc="Best-in-class WordPress setup, ready instantly." />
            <BenefitItem icon={Users} title="Expert Support" desc="Real humans ready to help you 24/7." />
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-16 text-bh-blue">Why thousands choose Bluehost</h2>
          <div className="grid gap-12 text-left">
            {[
              { icon: MousePointer2, t: "No experience needed", d: "If you can use a mouse, you can build a professional site. Our guided setup walks you through every click." },
              { icon: Clock, t: "Launch in minutes", d: "From idea to URL before your coffee gets cold. Most of our users go live in under 45 minutes." },
              { icon: Rocket, t: "Everything in one place", d: "No more managing 5 different passwords. Your domain, hosting, and email are all under one roof." },
              { icon: DollarSign, t: "Low starting cost", d: "Professional hosting at a fraction of a developer's price. Perfect for bootstrapped entrepreneurs." }
            ].map((item, i) => (
              <div key={i} className="flex gap-6 group">
                <div className="w-14 h-14 rounded-2xl bg-white border border-black/5 shadow-sm flex items-center justify-center text-bh-blue flex-shrink-0 group-hover:scale-110 transition-transform">
                  <item.icon className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-xl font-black mb-1 text-bh-blue">{item.t}</h4>
                  <p className="text-bh-ink-light leading-relaxed">{item.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section className="py-24 px-6 bg-bh-blue text-white rounded-[40px] mx-6 md:mx-12 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-white/5 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
        <div className="max-w-5xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-5xl font-black tracking-tight text-center mb-20 leading-tight italic">Success in 3 Simple Steps</h2>
          <div className="grid md:grid-cols-3 gap-12">
            {[
              { n: '01', t: "Choose Plan", d: "Pick the speed and storage that fits your goal." },
              { n: '02', t: "Pick Domain", d: "Secure your unique name for free instantly." },
              { n: '03', t: "Launch!", d: "One click install WordPress and you're online." }
            ].map((step, i) => (
              <div key={i} className="text-center">
                <div className="text-[80px] font-black opacity-10 leading-none mb-4 -ml-4">{step.n}</div>
                <h3 className="text-2xl font-black mb-3">{step.t}</h3>
                <p className="text-white/60 text-sm leading-relaxed">{step.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-32 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-black tracking-tight text-bh-blue mb-4 leading-tight">The Right Plan for Your Journey</h2>
          <p className="text-bh-ink-light mb-20 font-medium">Transparent pricing. No hidden cloud fees.</p>
          <div className="grid md:grid-cols-3 gap-8 items-center">
            <PlanCard title="Starter" desc="Perfect for your first blog or profile." price="2.95" />
            <PlanCard title="Choice Plus" desc="Best for growing businesses & extra protection." price="5.45" popular />
            <PlanCard title="Online Store" desc="Everything needed to sell products directly." price="9.95" />
          </div>
          
          <div className="mt-20 max-w-2xl mx-auto p-10 bg-white/50 border border-black/5 rounded-[32px] text-left">
            <h3 className="font-black text-xl mb-4 flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-bh-accent" />
              A note on transparency
            </h3>
            <p className="text-bh-ink-light text-sm leading-relaxed mb-4">
              At Bluehost, we believe in being realistic. The promotional prices listed above are for your <span className="font-bold underline">first term</span>. When you renew, the price will return to the regular rate.
            </p>
            <p className="text-bh-ink-light text-sm leading-relaxed">
              While our basic plans are incredible for starting, high-traffic businesses may eventually need to upgrade for performance. We're here to grow with you.
            </p>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-32 px-6 bg-white border-t border-black/5">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-7xl font-black tracking-tighter text-bh-blue mb-8 leading-[0.9]">
              Your online journey <br /> starts <span className="text-bh-accent italic">today.</span>
            </h2>
            <p className="text-xl md:text-2xl text-bh-ink-light mb-12 font-medium max-w-xl mx-auto leading-relaxed">
              Don't let technical worries stop your business from existing. Launch with confidence.
            </p>
            <button className="bg-bh-blue text-white px-12 py-6 rounded-[24px] font-black text-2xl shadow-2xl hover:scale-105 transition-transform">
              Start Your Website with Bluehost
            </button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-black/5 text-center text-[10px] uppercase font-bold text-bh-ink-light tracking-widest leading-loose">
        <p>© 2026 InstantLaunch Platform. This page contains affiliate links. | Host with Confidence</p>
        <div className="flex justify-center gap-8 mt-4 text-[8px] opacity-60">
           <a href="#" className="hover:text-bh-blue">Privacy Policy</a>
           <a href="#" className="hover:text-bh-blue">Terms of Service</a>
           <a href="#" className="hover:text-bh-blue">DMCA</a>
        </div>
      </footer>
    </div>
  );
}
